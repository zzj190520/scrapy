# -*- coding: utf-8 -*-
import scrapy


class ItcastSpider(scrapy.Spider):
    name = 'itcast'  #爬虫名
    allowed_domains = ['itcast.cn']
    start_urls = ['http://www.itcast.cn/channel/teacher.shtml']

    def parse(self, response):
        # li_list = response.xpath("//div[@class='tea_hd']//ul//li/text()").getall()
        # for li in li_list:
        li_list = response.xpath("//div[@class='tea_con']//ul//li")
        for li in li_list:
            item = {}
            item['name'] = li.xpath(".//h3/text()").get()
            item['title'] = li.xpath(".//h4/text()").get()
            # item['content'] = li.xpath(".//div[@class='li_txt']/p/text()").get()
            print(item)

